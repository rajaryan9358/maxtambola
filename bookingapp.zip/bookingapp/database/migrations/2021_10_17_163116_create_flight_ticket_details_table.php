<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateFlightTicketDetailsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('flight_ticket_details', function (Blueprint $table) {
            $table->id();
            $table->bigInteger('user_id');
            $table->string('flight_name_time');
            $table->string('from_dest');
            $table->string('to_dest');
            $table->date('date_of_journey');
            $table->string('travel_class');
            $table->string('mobile_number');
            $table->string('email_address');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('flight_ticket_details');
    }
}
