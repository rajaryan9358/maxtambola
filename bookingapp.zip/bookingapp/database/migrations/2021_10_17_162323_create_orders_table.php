<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateOrdersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('orders', function (Blueprint $table) {
            $table->id();
            $table->bigInteger('user_id');
            $table->decimal('price_amount')->nullable();
            $table->decimal('charge_amount')->nullable();
            $table->decimal('total_amount')->nullable();
            $table->string('status');
            $table->dateTime('status_updated_at');
            $table->string('order_time');
            $table->string('user_title');
            $table->string('admin_title');
            $table->string('message');
            $table->string('tag_type');
            $table->bigInteger('tag_id');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('orders');
    }
}
