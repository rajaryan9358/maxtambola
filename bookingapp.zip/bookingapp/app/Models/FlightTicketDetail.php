<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class FlightTicketDetail extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id',
        'flight_name_time',
        'from_dest',
        'to_dest',
        'date_of_journey',
        'travel_class',
        'mobile_number',
        'email_address',
    ];
}
