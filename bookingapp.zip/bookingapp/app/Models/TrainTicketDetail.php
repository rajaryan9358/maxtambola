<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class TrainTicketDetail extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id',
        'train_no_name',
        'from_dest',
        'to_dest',
        'date_of_journey',
        'travel_class',
        'mobile_number',
        'destination_address',
        'pin_code',
    ];
}
