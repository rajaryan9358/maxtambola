<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class MobileRecharge extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id',
        'recharge_type',
        'mobile',
        'operator',
        'operator_id',
        'amount',
    ];
}
