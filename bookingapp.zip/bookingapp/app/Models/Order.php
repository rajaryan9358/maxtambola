<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Order extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id',
        'price_amount',
        'charge_amount',
        'total_amount',
        'status',
        'status_updated_at',
        'order_time',
        'user_title',
        'admin_title',
        'message',
        'tag_type',
        'tag_id',
    ];
}
