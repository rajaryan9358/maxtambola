<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ElectricBill extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id',
        'consumer_id',
        'consumer_name',
        'payment_for_month',
        'amount',
    ];
}
