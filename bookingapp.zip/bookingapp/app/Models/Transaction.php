<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Transaction extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id',
        'order_id',
        'txn_status',
        'txn_user_title',
        'txn_admin_title',
        'message',
        'txn_amount',
    ];
}
