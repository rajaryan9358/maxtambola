<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class TicketPassenger extends Model
{
    use HasFactory;

    protected $fillable = [
        'tag_type',
        'tag_id',
        'name',
        'gender',
        'date_of_birth',
        'age',
    ];
}
