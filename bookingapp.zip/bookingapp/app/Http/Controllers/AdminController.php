<?php

namespace App\Http\Controllers;

use App\Models\Admin;
use App\Models\BusTicketDetail;
use App\Models\Chat;
use App\Models\DthRecharge;
use App\Models\ElectricBill;
use App\Models\FlightTicketDetail;
use App\Models\Message;
use App\Models\MobileRecharge;
use App\Models\Order;
use App\Models\Setting;
use App\Models\TicketPassenger;
use App\Models\TrainTicketDetail;
use App\Models\Transaction;
use App\Models\User;
use Carbon\Carbon;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use PDO;

class AdminController extends Controller
{
    //Admin App API

    //1. Login admin
    //2. Get orders by Tag (Pagination)
    //3. Get order details
    //4. Get account data for selected date range
    //5. Get enquiry chat list sorted by updated at desc
    //6. Get messages by chat id
    //7. Get users list
    //8. Get users account
    //9. Get user details
    //10. Block user
    //11. Send notification to user
    //12. Send notification by categories
    //13. Accept or Reject Request
    //14. Cancel a request
    //15. Mark complete request
    //16. Add Balance due to user transaction
    //17. Settle a transaction
	//18. Due remainder to everyone
	//19. Due remainder to single user
	//20. Get transaction total for selected date range


	//1. Login admin
	public function login_admin(Request $request){
		$userName=$request->user_name;
		$password=$request->password;

		$admin=Admin::where('user_name',$userName)
					->where('password',$password)
					->first();

		if($admin){
			return response()->json(['status' => 'SUCCESS', 'code' => 'SC_01', 'data' => $admin]);
		}

		return response()->json(['status' => 'SUCCESS', 'code' => 'FC_01', 'data' => null]);

	}


    //2. Get orders by Tag (Pagination)
	public function get_orders(Request $request){
		$tag=$request->tag;
		$status=$request->status;
		$fromId=$request->from_id;

		if($tag=="ALL"&&$status=="ALL"){
			if($fromId==0){
				$orders=Order::orderBy('id','DESC')
							->limit(20)
							->get();
			}else{
				$orders=Order::where('id','<',$fromId)
							->orderBy('id','DESC')
							->limit(20)
							->get();
			}
						
		}else{
			if($tag=="ALL"){

				if($fromId==0){
					$orders=Order::where('status',$status)
								->orderBy('id','DESC')
								->limit(20)
								->get();
				}else{
					$orders=Order::where('status',$status)
								->where('id','<',$fromId)
								->orderBy('id','DESC')
								->limit(20)
								->get();
				}

			}else if($status=="ALL"){
				if($fromId==0){
					$orders=Order::where('tag_type',$tag)
								->orderBy('id','DESC')
								->limit(20)
								->get();
				}else{
					$orders=Order::where('tag_type',$tag)
								->where('id','<',$fromId)
								->orderBy('id','DESC')
								->limit(20)
								->get();
				}
			}else{
				if($fromId==0){
					$orders=Order::where('status',$status)
								->where('tag_type',$tag)
								->orderBy('id','DESC')
								->limit(20)
								->get();
				}else{
					$orders=Order::where('status',$status)
								->where('tag_type',$tag)
								->where('id','<',$fromId)
								->orderBy('id','DESC')
								->limit(20)
								->get();
				}
			}
		}

		return response()->json(['status' => 'SUCCESS', 'code' => 'SC_01', 'data' => $orders]);
	}


    //3. Get order details
	public function get_order_details($orderId){
		$accountData=[];

        $order=Order::where('id',$orderId)->first();
        $user=User::select('name','phone','whatsapp')
				->where('id',$order->user_id)->first();

        if($order->tag_type=="TRAIN-TICKET"){
            $tagData=TrainTicketDetail::where('id',$order->tag_id)->first();
            $passengers=TicketPassenger::where('tag_type',"TRAIN-TICKET")
                                        ->where('tag_id',$order->tag_id)
                                        ->get();
            $tagData['passengers']=$passengers;

            $accountData['train_ticket']=$tagData;

        }else if($order->tag_type=="BUS-TICKET"){
            $tagData=BusTicketDetail::where('id',$order->tag_id)->first();
            $passengers=TicketPassenger::where('tag_type',"BUS-TICKET")
                                        ->where('tag_id',$order->tag_id)
                                        ->get();
            $tagData['passengers']=$passengers;

            $accountData['bus_ticket']=$tagData;

        }else if($order->tag_type=="FLIGHT-TICKET"){
            $tagData=FlightTicketDetail::where('id',$order->tag_id)->first();
            $passengers=TicketPassenger::where('tag_type',"FLIGHT-TICKET")
                                        ->where('tag_id',$order->tag_id)
                                        ->get();
            $tagData['passengers']=$passengers;

            $accountData['flight_ticket']=$tagData;

        }else if($order->tag_type=="ELECTRIC-BILL"){
            $tagData=ElectricBill::where('id',$order->tag_id)->first();

            $accountData['electric_bill']=$tagData;

        }else if($order->tag_type=="MOBILE-RECHARGE"){
            $tagData=MobileRecharge::where('id',$order->tag_id)->first();

            $accountData['mobile_recharge']=$tagData;

        }else if($order->tag_type=="DTH-RECHARGE"){
            $tagData=DthRecharge::where('id',$order->tag_id)->first();

            $accountData['dth_recharge']=$tagData;
        }

        $accountData['order']=$order;
        $accountData['user']=$user;

        return response()->json(['status' => 'SUCCESS', 'code' => 'SC_01', 'data' => $accountData]);
	}


    //4. Get account data for selected date range
	public function account_data_range(Request $request){
		$type=$request->type;
		$fromId=$request->from_id;

		$now=new Carbon();
		$nowDateTime=$now->toDateTimeString();
		$lastWeekDateTime=$now->addDays(-7)->toDateTimeString();
		$now->addDays(7);
		$lastMonthDateTime=$now->addDays(-30)->toDateTimeString();

		$dateFrom="";
		$dateTo="";

		if($type=="ALL"){
			if($fromId==0){
				$accounts=Transaction::orderBy('created_at','DESC')
									->limit(20)
									->get();
			}else{
				$accounts=Transaction::orderBy('created_at','DESC')
									->orderBy('id','<',$fromId)
									->limit(20)
									->get();
			}

		}else if($type=="LAST WEEK"){
			$dateFrom=$lastWeekDateTime;
			$dateTo=$nowDateTime;

		}else if($type=="LAST MONTH"){
			$dateFrom=$lastMonthDateTime;
			$dateTo=$nowDateTime;

		}else if($type=="DATE RANGE"){
			$dateFrom=$request->date_from.' 00:00:00';
			$dateTo=$request->date_to.' 23:59:59';

		}
		
		if($type!="ALL"){
			if($fromId==0){
				$accounts=Transaction::where('created_at','>',$dateFrom)
									->where('created_at','<',$dateTo)
									->orderBy('created_at','DESC')
									->limit(20)
									->get();
			}else{
				$accounts=Transaction::where('created_at','>',$dateFrom)
									->where('created_at','<',$dateTo)
									->orderBy('created_at','DESC')
									->orderBy('id','<',$fromId)
									->limit(20)
									->get();
			}
		}

		return response()->json(['status' => 'SUCCESS', 'code' => 'SC_01', 'data' => $accounts]);
	}


    //5. Get enquiry chat list sorted by updated at desc
	public function get_chat_users(Request $request){
		$fromId=$request->from_id;

		if($fromId==0){
			$chats=Chat::leftjoin('users','users.id','chats.user_id')
						->select('chats.*','users.name')
						->orderBy('chats.id','DESC')
						->orderBy('chats.updated_at','DESC')
						->limit(20)
						->get();
		}else{
			$chats=Chat::leftjoin('users','users.id','chats.user_id')
						->select('chats.*','users.name')
						->where('chats.id','<',$fromId)
						->orderBy('chats.id','DESC')			
						->orderBy('chats.updated_at','DESC')
						->limit(20)
						->get();
		}


		return response()->json(['status' => 'SUCCESS', 'code' => 'SC_01', 'data' => $chats]);
	}


    //6. Get messages by chat id
	public function get_message_by_id(Request $request){
		$chatId=$request->chat_id;
		$fromId=$request->from_id;

		if($fromId==0){
			$messages=Message::where('chat_id',$chatId)
							->orderBy('id','DESC')
							->orderBy('created_at','DESC')
							->limit(20)
							->get();
		}else{
			$messages=Message::where('chat_id',$chatId)
							->where('id','<',$fromId)
							->orderBy('id','DESC')
							->orderBy('created_at','DESC')
							->limit(20)
							->get();
		}

		return response()->json(['status' => 'SUCCESS', 'code' => 'SC_01', 'data' => $messages]);
	}


    //7. Get users list
	public function get_users_list(Request $request){
		$search=$request->search;
		$fromId=$request->from_id;

		if($fromId==0){
			$users=User::where('name','like','%'.$search.'%')
						->orderBy('created_at','DESC')
						->limit(20)
						->get();
		}else{
			$users=User::where('name','like','%'.$search.'%')
						->where('id','<',$fromId)
						->orderBy('created_at','DESC')
						->limit(20)
						->get();
		}

		return response()->json(['status' => 'SUCCESS', 'code' => 'SC_01', 'data' => $users]);
	}


    //8. Get users account
    //    ---- Refer to get accounts in UserController



	//9. Get user details
	public function get_users_detail($userId){
		$user=User::where('id',$userId)
					->first();

		return response()->json(['status' => 'SUCCESS', 'code' => 'SC_01', 'data' => $user]);			
	}


    //10. Block user
	public function block_unblock_user($userId){
		$user=User::where('id',$userId)->first();

		if($user->is_blocked==0){
			$user->is_blocked=1;
		}else{
			$user->is_blocked=0;
		}

		$user->save();

		return response()->json(['status' => 'SUCCESS', 'code' => 'SC_01', 'data' => $user]);			
	}


    //11. Send notification to user
	public function send_user_notification(Request $request){
		$userId=$request->user_id;
		$title=$request->title;
		$message=$request->message;

		$user=User::where('id',$userId)->first();

		$tokenList=[];
		array_push($tokenList,$user->token);

		$this->notification($tokenList,$title,$message);
		return response()->json(['status' => 'SUCCESS', 'code' => 'SC_01', 'data' => null]);			
	}

    //12. Send notification by categories
	public function send_notificaiton_category(Request $request){
		$type=$request->type;
		$status=$request->status;
		$title=$request->title;
		$message=$request->message;

		$userIds=Order::where('tag_type',$type)
					->where('status',$status)
					->pluck('user_id');

		$tokens=User::whereIn('id',$userIds)
					->pluck('token');

		$tokenList=[];

		foreach($tokens as $token){
			if(!array_key_exists($token,$tokenList)){
				array_push($tokenList,$token);
			}
		}

		$this->notification($tokenList,$title,$message);

		return response()->json(['status' => 'SUCCESS', 'code' => 'SC_01', 'data' => null]);			
	}


    //13. Accept or Reject Request
	public function accept_reject_order(Request $request){
		$orderId=$request->order_id;
		$status=$request->status;
		$message=$request->message;

		$order=Order::where('id',$orderId)->first();

		$order->status=$status;
		$order->status_updated_at=now();
		$order->message=$message;

		$order->save();

		$notificationMsg="";$title="";

		if($order->tag_type=="TRAIN-TICKET"){
			$notificationMsg="Train Ticket request ";
		}else if($order->tag_type=="BUS-TICKET"){
			$notificationMsg="Bus Ticket ";
		}else if($order->tag_type=="FLIGHT-TICKET"){
			$notificationMsg="Flight Ticket request ";
		}else if($order->tag_type=="ELECTRIC-BILL"){
			$notificationMsg="Electric Bill request ";
		}else if($order->tag_type=="MOBILE-RECHARGE"){
			$notificationMsg="Mobile Recharge request ";
		}else if($order->tag_type=="DTH-RECHARGE"){
			$notificationMsg="DTH Recharge request ";
		}

		if($status=="ACCEPTED"){
			$title="Order accepted";
			$notificationMsg=$notificationMsg." accepted";
		}else{
			$title="Order rejected";
			$notificationMsg=$notificationMsg." rejected";
		}

		$user=User::where('id',$order->user_id)->first();

		$tokenList=[];
		array_push($tokenList,$user->token);

		$this->notification($tokenList,$title,$notificationMsg);

		return response()->json(['status' => 'SUCCESS', 'code' => 'SC_01', 'data' => $order]);			
	}


    //14. Cancel a request
	public function cancel_request_admin(Request $request){
		$orderId=$request->order_id;
		$message=$request->message;

		$order=Order::where('id',$orderId)->first();

		$order->status="CANCELLED";
		$order->status_updated_at=now();
		$order->message=$message;

		$order->save();

		$notificationMsg="";$title="";

		if($order->tag_type=="TRAIN-TICKET"){
			$notificationMsg="Train Ticket request ";
		}else if($order->tag_type=="BUS-TICKET"){
			$notificationMsg="Bus Ticket ";
		}else if($order->tag_type=="FLIGHT-TICKET"){
			$notificationMsg="Flight Ticket request ";
		}else if($order->tag_type=="ELECTRIC-BILL"){
			$notificationMsg="Electric Bill request ";
		}else if($order->tag_type=="MOBILE-RECHARGE"){
			$notificationMsg="Mobile Recharge request ";
		}else if($order->tag_type=="DTH-RECHARGE"){
			$notificationMsg="DTH Recharge request ";
		}

		$title="Order cancelled";
		$notificationMsg=$notificationMsg."cancelled by admin";

		$user=User::where('id',$order->user_id)->first();

		$tokenList=[];
		array_push($tokenList,$user->token);

		$this->notification($tokenList,$title,$notificationMsg);

		return response()->json(['status' => 'SUCCESS', 'code' => 'SC_01', 'data' => $order]);	

	}


    //15. Mark complete request
	public function mark_order_complete(Request $request){
		$orderId=$request->order_id;
		$message=$request->message;
		$priceAmount=$request->price_amount;
		$chargeAmount=$request->charge_amount;

		DB::beginTransaction();

		try{
			$order=Order::where('id',$orderId)->first();
			$user=User::where('id',$order->user_id)->first();
	
			$order->status="COMPLETED";
			$order->status_updated_at=now();
			$order->message=$message;
			$order->price_amount=$priceAmount;
			$order->charge_amount=$chargeAmount;
			$order->total_amount=$priceAmount+$chargeAmount;
	
			$order->save();
	
			$transactionData=[];
			$transactionData['user_id']=$order->user_id;
			$transactionData['order_id']=$orderId;
			$transactionData['txn_status']="PENDING";
			$transactionData['txn_user_title']=$order->user_title." - ".$order->id;
			$transactionData['txn_admin_title']=$order->user_title." - ".$user->name." (".$order->id.")";
			$transactionData['txn_amount']=$order->total_amount;
			$transactionData['message']=$message;
	
			$transaction=Transaction::create($transactionData);
	
			$user->due_balance=$user->due_balance+$order->total_amount;
			$user->save();
	
			$notificationMsg="";$title="";
	
			if($order->tag_type=="TRAIN-TICKET"){
				$notificationMsg="Train Ticket request ";
			}else if($order->tag_type=="BUS-TICKET"){
				$notificationMsg="Bus Ticket ";
			}else if($order->tag_type=="FLIGHT-TICKET"){
				$notificationMsg="Flight Ticket request ";
			}else if($order->tag_type=="ELECTRIC-BILL"){
				$notificationMsg="Electric Bill request ";
			}else if($order->tag_type=="MOBILE-RECHARGE"){
				$notificationMsg="Mobile Recharge request ";
			}else if($order->tag_type=="DTH-RECHARGE"){
				$notificationMsg="DTH Recharge request ";
			}
	
			$title="Order completed";
			$notificationMsg=$notificationMsg."completed successfully";
	
	
			$tokenList=[];
			array_push($tokenList,$user->token);
	
			$this->notification($tokenList,$title,$notificationMsg);
	
			DB::commit();
			return response()->json(['status' => 'SUCCESS', 'code' => 'SC_01', 'data' => $order]);	
		}catch(Exception $e){
			DB::rollBack();
			return response()->json(['status' => 'SUCCESS', 'code' => 'FC_01', 'data' => null]);	
		}

		
	}


    //16. Add Balance due to user transaction
	public function add_due_balance(Request $request){
		$userId=$request->user_id;
		$txnTitle=$request->txn_title;
		$txnAmount=$request->txn_amount;
		$message=$request->message;

		DB::beginTransaction();

		try{
			
			$user=User::where('id',$userId)->first();

			$transactionData=[];
			$transactionData['user_id']=$userId;
			$transactionData['order_id']=-1;
			$transactionData['txn_status']="PENDING";
			$transactionData['txn_user_title']=$txnTitle;
			$transactionData['txn_admin_title']="Due created by admin";
			$transactionData['txn_amount']=$txnAmount;
			$transactionData['message']=$message;

			$transaction=Transaction::create($transactionData);

			$user->due_balance=$user->due_balance+$txnAmount;
			$user->save();

			DB::commit();

			$tokenList=[];
			array_push($tokenList,$user->token);

			$title="Due balance update";
			$notificationMsg="Rs ".$txnAmount." due added to your account";
	
			$this->notification($tokenList,$title,$notificationMsg);
			return response()->json(['status' => 'SUCCESS', 'code' => 'SC_01', 'data' => $transaction]);	
		}catch(Exception $e){
			DB::rollBack();
			return response()->json(['status' => 'SUCCESS', 'code' => 'FC_01', 'data' => null]);	
		}
	}


    //17. Settle a transaction
	public function settle_transaction(Request $request){
		$txnId=$request->txn_id;

		DB::beginTransaction();

		try{
			
			$transaction=Transaction::where('id',$txnId)->first();

			$user=User::where('id',$transaction->user_id)->first();

			$transaction->txn_status="SETTLED";
			$transaction->message="Due settled by admin on ".now();

			$transaction->save();

			$user->due_balance=$user->due_balance-$transaction->txn_amount;
			$user->save();

			DB::commit();

			$tokenList=[];
			array_push($tokenList,$user->token);

			$title="Due balance settled";
			$notificationMsg="Rs ".$transaction->txn_amount." due settled in your account";
	
			$this->notification($tokenList,$title,$notificationMsg);
			return response()->json(['status' => 'SUCCESS', 'code' => 'SC_01', 'data' => $transaction]);	
		}catch(Exception $e){
			DB::rollBack();
			return response()->json(['status' => 'SUCCESS', 'code' => 'FC_01', 'data' => null]);	
		}
	}


	//18. Due remainder to everyone
	public function due_remainder_everyone(Request $request){
		$message=$request->message;

		$transactionUserIds=Transaction::where('txn_status','PENDING')
							->pluck('user_id');

		$tokens=User::whereIn('id',$transactionUserIds)
					->pluck('token');

		$tokenList=[];
		foreach($tokens as $token){
			if(!array_key_exists($token,$tokenList)){
				array_push($tokenList,$token);
			}
		}

		$this->notification($tokenList,"Due Remainder",$message);
		return response()->json(['status' => 'SUCCESS', 'code' => 'SC_01', 'data' => null]);	
	}


	//19. Due remainder to single user
	public function due_remainder_single_user(Request $request){
		$message=$request->message;
		$userId=$request->user_id;

		$transactionUserIds=Transaction::where('txn_status','PENDING')
							->where('user_id',$userId)
							->pluck('user_id');

		$tokens=User::whereIn('id',$transactionUserIds)
					->pluck('token');

		$tokenList=[];
		foreach($tokens as $token){
			if(!array_key_exists($token,$tokenList)){
				array_push($tokenList,$token);
			}
		}

		// $this->notification($tokenList,"Due Remainder","You have ".count($transactionUserIds)." due balance. Please clear it as early.");
		$this->notification($tokenList,"Due Remainder",$message);
		return response()->json(['status' => 'SUCCESS', 'code' => 'SC_01', 'data' => null]);
	}


	//20. Get transaction total for selected date range
	public function get_transaction_total_range(Request $request){
		$type=$request->type;

		$now=new Carbon();
		$nowDateTime=$now->toDateTimeString();
		$lastWeekDateTime=$now->addDays(-7)->toDateTimeString();
		$now->addDays(7);
		$lastMonthDateTime=$now->addDays(-30)->toDateTimeString();

		$dateFrom="";
		$dateTo="";

		//Earning from the orders table
		//Due balance = Total of pending transactions

		$totalDueBalance=0;
		$totalEarning=0;

		$transactionResult=[];

		if($type=="ALL"){
			$accounts=Transaction::where('txn_status','PENDING')
								->select('txn_amount','order_id')
								->get();

			$orderIds=[];
			foreach($accounts as $account){
				$totalDueBalance+=$account['txn_amount'];
				if(!array_key_exists($account['order_id'],$orderIds)){
					array_push($orderIds,$account['order_id']);
				}
			}

			$orders=Order::whereIn('id',$orderIds)
						->select('charge_amount')
						->get();

			foreach($orders as $order){
				$totalEarning+=$order['charge_amount'];
			}

			$transactionResult['total_due_balance']=$totalDueBalance;
			$transactionResult['total_earning']=$totalEarning;

		}else if($type=="LAST WEEK"){
			$dateFrom=$lastWeekDateTime;
			$dateTo=$nowDateTime;

		}else if($type=="LAST MONTH"){
			$dateFrom=$lastMonthDateTime;
			$dateTo=$nowDateTime;

		}else if($type=="DATE RANGE"){
			$dateFrom=$request->date_from.' 00:00:00';
			$dateTo=$request->date_to.' 23:59:59';

		}
		
		if($type!="ALL"){
			$accounts=Transaction::where('created_at','>',$dateFrom)
								->where('created_at','<',$dateTo)
								->where('txn_status','PENDING')
								->select('txn_amount','order_id')
								->get();

			$orderIds=[];
			foreach($accounts as $account){
				$totalDueBalance+=$account['txn_amount'];
				if(!array_key_exists($account['order_id'],$orderIds)){
					array_push($orderIds,$account['order_id']);
				}
			}

			$orders=Order::whereIn('id',$orderIds)
						->select('charge_amount')
						->get();

			foreach($orders as $order){
				$totalEarning+=$order['charge_amount'];
			}

			$transactionResult['total_due_balance']=$totalDueBalance;
			$transactionResult['total_earning']=$totalEarning;
		}

		return response()->json(['status' => 'SUCCESS', 'code' => 'SC_01', 'data' => $transactionResult]);
	}



    public function notification($tokenList, $title, $message)
	{

		$setting=Setting::where('id',1)->first();
		$auth=$setting->google_auth;

		$fcmUrl = 'https://fcm.googleapis.com/fcm/send';
		// $token=$token;

		$notification = [
			'title' => $title,
			'body' => $message,
			'sound' => true,
		];

		$extraNotificationData = ["message" => $notification];

		$fcmNotification = [
			'registration_ids' => $tokenList, //multple token array
			// 'to'        => $token, //single token
			'notification' => $notification,
			'data' => $extraNotificationData
		];

		$headers = [
			'Authorization: key=' . $auth,
			'Content-Type: application/json'
		];


		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $fcmUrl);
		curl_setopt($ch, CURLOPT_POST, true);
		curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fcmNotification));
		$result = curl_exec($ch);
		curl_close($ch);

		return true;
	}


}
