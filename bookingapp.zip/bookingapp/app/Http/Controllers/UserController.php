<?php

namespace App\Http\Controllers;

use App\Models\Admin;
use App\Models\BusTicketDetail;
use App\Models\Chat;
use App\Models\DthOperator;
use App\Models\DthRecharge;
use App\Models\ElectricBill;
use App\Models\FlightTicketDetail;
use App\Models\Message;
use App\Models\MobileOperator;
use App\Models\MobileRecharge;
use App\Models\Order;
use App\Models\Setting;
use App\Models\TicketPassenger;
use App\Models\TrainTicketDetail;
use App\Models\Transaction;
use App\Models\User;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class UserController extends Controller
{
    

    //User app API

    //1. Send otp
    //2. Verify Otp
    //3. Register User
    //4. Update User Profile
    //5. Get my accounts (Pagination)
    //6. Get my chats (Pagination)
    //7. Book train ticket __ORDER__
    //8. Book bus ticket __ORDER__
    //9. Book flight ticket __ORDER__
    //10. Submit Electric Bill payment __ORDER__
    //11. Submit Mobile recharge payement __ORDER__
    //12. Submit Dth Recharge payment __ORDER__
    //13. Get mobile operators
    //14. Get dth operators
    //15. Get account details (Ticket, Bill, Recharge etc...)
    //16. Get my profile
    //17. Send Enquiry message
    //18. Mark Message Read
    //19. Cancel a request
    //20. Get Transactions
    //21. Get my transaction total



    //1. Send Otp
	public function send_otp(Request $request){
		$phone=$request->phone;

		$user=User::where('phone',$phone)->first();

		if(!$user){
			$userData=[];
			$userData['phone']=$phone;
			$otp=$this->getOtp(4);
			$userData['otp']=$otp;

			$this->sendOtp($otp,$phone);

			$user=User::create($userData);
		}else{
			$otp=$this->getOtp(4);
			$user->otp=$otp;
			$this->sendOtp($otp,$phone);
			$user->save();
		}

		return response()->json(['status' => 'SUCCESS', 'code' => 'SC_01', 'data' => null]);
	}

	public function sendOtp($otp,$number){
		$otpData=[];
		$otpData['variables_values']=$otp;
		$otpData['route']="otp";
		$otpData['numbers']=$number;

		$setting=Setting::first();
		$apiKey=$setting->sms_api;

		$data_string = json_encode($otpData);

			$ch = curl_init("https://www.fast2sms.com/dev/bulkV2");
			curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
			curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			curl_setopt(
				$ch,
				CURLOPT_HTTPHEADER,
				array(
					'authorization:'.$apiKey,
                    'Content-Type: application/json',
                    'Content-Length: ' . strlen($data_string)			
					)
			);

			curl_exec($ch) . "\n";
			curl_close($ch);
	}

	//2. Verify Otp
	public function verify_otp(Request $request){
		$phone=$request->phone;
		$otp=$request->otp;
		$token=$request->token;

		$user=User::where('phone',$phone)
					->where('otp',$otp)
					->first();

		if($user){
			$user->token=$token;
			$user->save();
			if($user->name==null)
			return response()->json(['status' => 'SUCCESS', 'code' => 'SC_01', 'data' => $user]);
			else
			return response()->json(['status' => 'SUCCESS', 'code' => 'SC_02', 'data' => $user]);
		}

		return response()->json(['status' => 'SUCCESS', 'code' => 'FC_01', 'data' => null]);
					
	}

	function getOtp($n)
	{
		$characters = '0123456789';
		$randomString = '';

		for ($i = 0; $i < $n; $i++) {
			$index = rand(0, strlen($characters) - 1);
			$randomString .= $characters[$index];
		}

		return $randomString;
	}


    //3. Register User
    public function register_user(Request $request){
        $name=$request->name;
        $phone=$request->phone;
        $token=$request->token;
        $whatsapp=$request->whatsapp;

        $user=User::where('phone',$phone)->first();

        if($user){
            if($user->name==null){
                $user->name=$name;
                $user->token=$token;
                $user->whatsapp=$whatsapp;

                $user->save();
            }
        }

        return response()->json(['status' => 'SUCCESS', 'code' => 'SC_01', 'data' => $user]);
    }


    //4. Update User Profile
    public function update_profile(Request $request){
        $userId=$request->user_id;
        $name=$request->name;
        $whatsapp=$request->whatsapp;

        $user=User::where('id',$userId)->first();

        if($user){
            $user->name=$name;
            $user->whatsapp=$whatsapp;

            $user->save();
        }

        return response()->json(['status' => 'SUCCESS', 'code' => 'SC_01', 'data' => $user]);
    }


    //5. Get my accounts (Pagination)
    public function get_accounts(Request $request){
        $fromId=$request->from_id;
        $userId=$request->user_id;

        if($fromId==0){
            $transactions=Order::where('user_id',$userId)
                                    ->orderBy('id','DESC')
                                    ->limit(20)
                                    ->get();
        }else{
            $transactions=Order::where('user_id',$userId)
                                    ->where('id','<',$fromId)
                                    ->orderBy('id','DESC')
                                    ->limit(20)
                                    ->get();
        }

        return response()->json(['status' => 'SUCCESS', 'code' => 'SC_01', 'data' => $transactions]);
    }


    //6. Get my chats (Pagination)
    public function get_my_chats(Request $request){
        $fromId=$request->from_id;
        $userId=$request->user_id;

        if($fromId==0){
            $messages=Message::where('sender_id',$userId)
                            ->orWhere('receiver_id',$userId)
                            ->orderBy('id','DESC')
                            ->limit(30)
                            ->get();
        }else{
            $messages=Message::where('sender_id',$userId)
                            ->orWhere('receiver_id',$userId)
                            ->where('id','<',$fromId)
                            ->orderBy('id','DESC')
                            ->limit(30)
                            ->get();
        }

        Message::where('receiver_id',$userId)->update(['is_read'=>1]);

        return response()->json(['status' => 'SUCCESS', 'code' => 'SC_01', 'data' => $messages]);
    }


    //7. Book train ticket __ORDER__
    public function book_train_ticket(Request $request){
        $userId=$request->user_id;
        $trainNoName=$request->train_no_name;
        $fromDest=$request->from_dest;
        $toDest=$request->to_dest;
        $dateOfJourney=$request->date_of_journey;
        $travelClass=$request->travel_class;
        $mobileNumber=$request->mobile_number;
        $destinationAddress=$request->destination_address;
        $pinCode=$request->pin_code;
        $passengers=$request->passengers;

        DB::beginTransaction();

        try{

            $user=User::where('id',$userId)->first();

            $trainTicketData=[];
            $trainTicketData['user_id']=$userId;
            $trainTicketData['train_no_name']=$trainNoName;
            $trainTicketData['from_dest']=$fromDest;
            $trainTicketData['to_dest']=$toDest;
            $trainTicketData['date_of_journey']=$dateOfJourney;
            $trainTicketData['travel_class']=$travelClass;
            $trainTicketData['mobile_number']=$mobileNumber;
            $trainTicketData['destination_address']=$destinationAddress;
            $trainTicketData['pin_code']=$pinCode;

            $trainTicket=TrainTicketDetail::create($trainTicketData);

            foreach($passengers as $passenger){
                $passengerData=[];
                $passengerData['tag_type']="TRAIN-TICKET";
                $passengerData['tag_id']=$trainTicket->id;
                $passengerData['name']=$passenger['name'];
                $passengerData['gender']=$passenger['gender'];

                if(array_key_exists('age',$passenger)){
                    $passengerData['age']=$passenger['age'];
                }
                if(array_key_exists('date_of_birht',$passenger)){
                    $passengerData['date_of_birth']=$passenger['date_of_birth'];
                }

                $newPassenger=TicketPassenger::create($passengerData);
            }

            $orderData=[];
            $orderData['user_id']=$userId;
            $orderData['status']="PENDING";
            $orderData['status_updated_at']=now();
            $orderData['order_time']=now();
            $orderData['user_title']="Train Ticket Booking";
            $orderData['admin_title']="Train Ticket request by ".$user->name;
            $orderData['message']="Waiting for acceptance from admin";
            $orderData['tag_type']="TRAIN-TICKET";
            $orderData['tag_id']=$trainTicket->id;

            $order=Order::create($orderData);


            DB::commit();

            $admin=Admin::where('id',0)->first();

            $tokenList=[];
            array_push($tokenList,$admin->token);

            $title="Train Ticket";
            $message="You have a new Train Ticket request from ".$user->name;

            $this->notification($tokenList,$title,$message);

            return response()->json(['status' => 'SUCCESS', 'code' => 'SC_01', 'data' => $order]);
        }catch(Exception $e){
            DB::rollBack();
            return response()->json(['status' => 'SUCCESS', 'code' => 'FC_02', 'data' => null]);
        }
    }


    //8. Book bus ticket __ORDER__
    public function book_bus_ticket(Request $request){
        $userId=$request->user_id;
        $busNoName=$request->bus_no_name;
        $fromDest=$request->from_dest;
        $toDest=$request->to_dest;
        $dateOfJourney=$request->date_of_journey;
        $mobileNumber=$request->mobile_number;
        $passengers=$request->passengers;

        DB::beginTransaction();

        try{

            $user=User::where('id',$userId)->first();

            $busTicketData=[];
            $busTicketData['user_id']=$userId;
            $busTicketData['bus_no_name']=$busNoName;
            $busTicketData['from_dest']=$fromDest;
            $busTicketData['to_dest']=$toDest;
            $busTicketData['date_of_journey']=$dateOfJourney;
            $busTicketData['mobile_number']=$mobileNumber;

            $busTicket=BusTicketDetail::create($busTicketData);

            foreach($passengers as $passenger){
                $passengerData=[];
                $passengerData['tag_type']="TRAIN-TICKET";
                $passengerData['tag_id']=$busTicket->id;
                $passengerData['name']=$passenger['name'];
                $passengerData['gender']=$passenger['gender'];

                if(array_key_exists('age',$passenger)){
                    $passengerData['age']=$passenger['age'];
                }
                if(array_key_exists('date_of_birth',$passenger)){
                    $passengerData['date_of_birth']=$passenger['date_of_birth'];
                }

                $newPassenger=TicketPassenger::create($passengerData);
            }

            $orderData=[];
            $orderData['user_id']=$userId;
            $orderData['status']="PENDING";
            $orderData['status_updated_at']=now();
            $orderData['order_time']=now();
            $orderData['user_title']="Bus Ticket Booking";
            $orderData['admin_title']="Bus Ticket request by ".$user->name;
            $orderData['message']="Waiting for acceptance from admin";
            $orderData['tag_type']="BUS-TICKET";
            $orderData['tag_id']=$busTicket->id;

            $order=Order::create($orderData);


            DB::commit();

            $admin=Admin::where('id',0)->first();

            $tokenList=[];
            array_push($tokenList,$admin->token);

            $title="Bus Ticket";
            $message="You have a new Bus Ticket request from ".$user->name;

            $this->notification($tokenList,$title,$message);

            return response()->json(['status' => 'SUCCESS', 'code' => 'SC_01', 'data' => $order]);
        }catch(Exception $e){
            DB::rollBack();
            return response()->json(['status' => 'SUCCESS', 'code' => 'FC_02', 'data' => null]);
        }
    }


    //9. Book flight ticket __ORDER__
    public function book_flight_ticket(Request $request){
        $userId=$request->user_id;
        $flightNameTime=$request->flight_name_time;
        $fromDest=$request->from_dest;
        $toDest=$request->to_dest;
        $dateOfJourney=$request->date_of_journey;
        $travelClass=$request->travel_class;
        $mobileNumber=$request->mobile_number;
        $emailAddress=$request->email_address;
        $passengers=$request->passengers;

        DB::beginTransaction();

        try{

            $user=User::where('id',$userId)->first();

            $flightTicketData=[];
            $flightTicketData['user_id']=$userId;
            $flightTicketData['flight_name_time']=$flightNameTime;
            $flightTicketData['from_dest']=$fromDest;
            $flightTicketData['to_dest']=$toDest;
            $flightTicketData['date_of_journey']=$dateOfJourney;
            $flightTicketData['travel_class']=$travelClass;
            $flightTicketData['mobile_number']=$mobileNumber;
            $flightTicketData['email_address']=$emailAddress;

            $flightTicket=FlightTicketDetail::create($flightTicketData);

            foreach($passengers as $passenger){
                $passengerData=[];
                $passengerData['tag_type']="TRAIN-TICKET";
                $passengerData['tag_id']=$flightTicket->id;
                $passengerData['name']=$passenger['name'];
                $passengerData['gender']=$passenger['gender'];

                if(array_key_exists('age',$passenger)){
                    $passengerData['age']=$passenger['age'];
                }
                if(array_key_exists('date_of_birth',$passenger)){
                    $passengerData['date_of_birth']=$passenger['date_of_birth'];
                }

                $newPassenger=TicketPassenger::create($passengerData);
            }

            $orderData=[];
            $orderData['user_id']=$userId;
            $orderData['status']="PENDING";
            $orderData['status_updated_at']=now();
            $orderData['order_time']=now();
            $orderData['user_title']="Flight Ticket Booking";
            $orderData['admin_title']="Flight Ticket request by ".$user->name;
            $orderData['message']="Waiting for acceptance from admin";
            $orderData['tag_type']="FLIGHT-TICKET";
            $orderData['tag_id']=$flightTicket->id;

            $order=Order::create($orderData);


            DB::commit();

            $admin=Admin::where('id',0)->first();

            $tokenList=[];
            array_push($tokenList,$admin->token);

            $title="Flight Ticket";
            $message="You have a new Flight Ticket request from ".$user->name;

            $this->notification($tokenList,$title,$message);

            return response()->json(['status' => 'SUCCESS', 'code' => 'SC_01', 'data' => $order]);
        }catch(Exception $e){
            DB::rollBack();
            return response()->json(['status' => 'SUCCESS', 'code' => 'FC_02', 'data' => null]);
        }
    }


    //10. Submit Electric Bill payment __ORDER__
    public function electric_bill_payment(Request $request){
        $userId=$request->user_id;
        $consumerId=$request->consumer_id;
        $consumerName=$request->consumer_name;
        $paymentForMonth=$request->payment_for_month;
        $amount=$request->amount;

        DB::beginTransaction();

        try{

            $user=User::where('id',$userId)->first();

            $electricBillData=[];
            $electricBillData['user_id']=$userId;
            $electricBillData['consumer_id']=$consumerId;
            $electricBillData['consumer_name']=$consumerName;
            $electricBillData['payment_for_month']=$paymentForMonth;
            $electricBillData['amount']=$amount;

            $electricBill=ElectricBill::create($electricBillData);

            $orderData=[];
            $orderData['user_id']=$userId;
            $orderData['status']="PENDING";
            $orderData['status_updated_at']=now();
            $orderData['order_time']=now();
            $orderData['user_title']="Electric Bill Payment";
            $orderData['admin_title']="Electric Bill payment request by ".$user->name;
            $orderData['message']="Waiting for acceptance from admin";
            $orderData['tag_type']="ELECTRIC-BILL";
            $orderData['tag_id']=$electricBill->id;

            $order=Order::create($orderData);


            DB::commit();

            $admin=Admin::where('id',0)->first();

            $tokenList=[];
            array_push($tokenList,$admin->token);

            $title="Electric Bill";
            $message="You have a new Electric Bill request from ".$user->name;

            $this->notification($tokenList,$title,$message);

            return response()->json(['status' => 'SUCCESS', 'code' => 'SC_01', 'data' => $order]);
        }catch(Exception $e){
            DB::rollBack();
            return response()->json(['status' => 'SUCCESS', 'code' => 'FC_02', 'data' => null]);
        }
    }


    //11. Submit Mobile recharge payement __ORDER__
    public function mobile_recharge_payment(Request $request){
        $userId=$request->user_id;
        $rechargeType=$request->recharge_type;
        $mobile=$request->mobile;
        $operator=$request->operator;
        $operatorId=$request->operator_id;
        $amount=$request->amount;

        DB::beginTransaction();

        try{

            $user=User::where('id',$userId)->first();

            $mobileRechargeData=[];
            $mobileRechargeData['user_id']=$userId;
            $mobileRechargeData['recharge_type']=$rechargeType;
            $mobileRechargeData['mobile']=$mobile;
            $mobileRechargeData['operator']=$operator;
            $mobileRechargeData['operator_id']=$operatorId;
            $mobileRechargeData['amount']=$amount;

            $mobileRecharge=MobileRecharge::create($mobileRechargeData);

            $orderData=[];
            $orderData['user_id']=$userId;
            $orderData['status']="PENDING";
            $orderData['status_updated_at']=now();
            $orderData['order_time']=now();
            $orderData['user_title']="Mobile Recharge";
            $orderData['admin_title']="Mobile Recharge request by ".$user->name;
            $orderData['message']="Waiting for acceptance from admin";
            $orderData['tag_type']="MOBILE-RECHARGE";
            $orderData['tag_id']=$mobileRecharge->id;

            $order=Order::create($orderData);


            DB::commit();

            $admin=Admin::where('id',0)->first();

            $tokenList=[];
            array_push($tokenList,$admin->token);

            $title="Mobile Recharge";
            $message="You have a new Mobile recharge request from ".$user->name;

            $this->notification($tokenList,$title,$message);

            return response()->json(['status' => 'SUCCESS', 'code' => 'SC_01', 'data' => $order]);
        }catch(Exception $e){
            DB::rollBack();
            return response()->json(['status' => 'SUCCESS', 'code' => 'FC_02', 'data' => null]);
        }
    }

    //12. Submit Dth Recharge payment __ORDER__
    public function dth_recharge(Request $request){
        $userId=$request->user_id;
        $operatorId=$request->operator_id;
        $operator=$request->operator;
        $smartCardNo=$request->smart_card_no;
        $amount=$request->amount;

        DB::beginTransaction();

        try{

            $user=User::where('id',$userId)->first();

            $dthRechargeData=[];
            $dthRechargeData['user_id']=$userId;
            $dthRechargeData['smart_card_no']=$smartCardNo;
            $dthRechargeData['operator']=$operator;
            $dthRechargeData['operator_id']=$operatorId;
            $dthRechargeData['amount']=$amount;

            $dthRecharge=DthRecharge::create($dthRechargeData);

            $orderData=[];
            $orderData['user_id']=$userId;
            $orderData['status']="PENDING";
            $orderData['status_updated_at']=now();
            $orderData['order_time']=now();
            $orderData['user_title']="DTH Recharge";
            $orderData['admin_title']="DTH Recharge request by ".$user->name;
            $orderData['message']="Waiting for acceptance from admin";
            $orderData['tag_type']="DTH-RECHARGE";
            $orderData['tag_id']=$dthRecharge->id;

            $order=Order::create($orderData);


            DB::commit();

            $admin=Admin::where('id',0)->first();

            $tokenList=[];
            array_push($tokenList,$admin->token);

            $title="DTH Recharge";
            $message="You have a new DTH recharge request from ".$user->name;

            $this->notification($tokenList,$title,$message);

            return response()->json(['status' => 'SUCCESS', 'code' => 'SC_01', 'data' => $order]);
        }catch(Exception $e){
            DB::rollBack();
            return response()->json(['status' => 'SUCCESS', 'code' => 'FC_02', 'data' => null]);
        }
    }


    //13. Get mobile operators
    public function get_mobile_operators(){

        $operators=MobileOperator::orderBy('priority','ASC')->get();
        return response()->json(['status' => 'SUCCESS', 'code' => 'SC_01', 'data' => $operators]);
    }


    //14. Get dth operators
    public function get_dth_operators(){
        $operators=DthOperator::orderBy('priority','ASC')->get();
        return response()->json(['status' => 'SUCCESS', 'code' => 'SC_01', 'data' => $operators]);
    }


    //15. Get account details (Ticket, Bill, Recharge etc...)
    public function get_account_details($orderId){
        
        $accountData=[];

        $order=Order::where('id',$orderId)->first();
        $user=User::select('name','phone','whatsapp')
                    ->where('id',$order->user_id)->first();

        if($order->tag_type=="TRAIN-TICKET"){
            $tagData=TrainTicketDetail::where('id',$order->tag_id)->first();
            $passengers=TicketPassenger::where('tag_type',"TRAIN-TICKET")
                                        ->where('tag_id',$order->tag_id)
                                        ->get();
            $tagData['passengers']=$passengers;

            $accountData['train_ticket']=$tagData;

        }else if($order->tag_type=="BUS-TICKET"){
            $tagData=BusTicketDetail::where('id',$order->tag_id)->first();
            $passengers=TicketPassenger::where('tag_type',"BUS-TICKET")
                                        ->where('tag_id',$order->tag_id)
                                        ->get();
            $tagData['passengers']=$passengers;

            $accountData['bus_ticket']=$tagData;

        }else if($order->tag_type=="FLIGHT-TICKET"){
            $tagData=FlightTicketDetail::where('id',$order->tag_id)->first();
            $passengers=TicketPassenger::where('tag_type',"FLIGHT-TICKET")
                                        ->where('tag_id',$order->tag_id)
                                        ->get();
            $tagData['passengers']=$passengers;

            $accountData['flight_ticket']=$tagData;

        }else if($order->tag_type=="ELECTRIC-BILL"){
            $tagData=ElectricBill::where('id',$order->tag_id)->first();

            $accountData['electric_bill']=$tagData;

        }else if($order->tag_type=="MOBILE-RECHARGE"){
            $tagData=MobileRecharge::where('id',$order->tag_id)->first();

            $accountData['mobile_recharge']=$tagData;

        }else if($order->tag_type=="DTH-RECHARGE"){
            $tagData=DthRecharge::where('id',$order->tag_id)->first();

            $accountData['dth_recharge']=$tagData;
        }

        $accountData['order']=$order;
        $accountData['user']=$user;

        return response()->json(['status' => 'SUCCESS', 'code' => 'SC_01', 'data' => $accountData]);
    }


    //16. Get my profile
    public function get_my_profile($userId){
        $user=User::where('id',$userId)->first();

        return response()->json(['status' => 'SUCCESS', 'code' => 'SC_01', 'data' => $user]);
    }


    //17. Send Enquiry message
    public function send_enquiry_message(Request $request){
        $senderId=$request->sender_id;
        $receiverId=$request->receiver_id;
        $message=$request->message;

        $chatUserId=-1;
       if($receiverId!=-1){
           $chatUserId=$receiverId;
       }else{
           $chatUserId=$senderId;
       }

       $chat=Chat::where('user_id',$chatUserId)->first();

       if(!$chat){
           $chatData=[];
           $chatData['user_id']=$chatUserId;
           $chatData['user_last_seen']=now();

           $chat=Chat::create($chatData);
       }

        $messageData=[];
        $messageData['sender_id']=$senderId;
        $messageData['receiver_id']=$receiverId;
        $messageData['message']=$message;
        $messageData['message_time']=now();
        $messageData['chat_id']=$chat->id;

        $message=Message::create($messageData);

        if($receiverId!=-1){
            $receiverUser=User::where('id',$receiverId)->first();

            $receiverToken=$receiverUser->token;
            $tokenList=[];
            array_push($tokenList,$receiverToken);
    
            $this->notification($tokenList,"New Message - Admin",$message);
        }else{
            $admin=Admin::where('id',0)->first();
            $senderUser=User::where('id',$senderId)->first();

            $senderName=$senderUser->name;
            $receiverToken=$admin->token;

            $tokenList=[];
            array_push($tokenList,$receiverToken);
    
            $this->notification($tokenList,"New Message - ".$senderName,$message);
        }
        

        return response()->json(['status' => 'SUCCESS', 'code' => 'SC_01', 'data' => $message]);
    }

    //18. Mark Message Read
    public function mark_message_read($messageId){

        $message=Message::where('id',$messageId)->first();
        $message->is_read=1;
        $message->save();

        return response()->json(['status' => 'SUCCESS', 'code' => 'SC_01', 'data' => $message]);
    }

    //19. Cancel a request
    public function cancel_request(Request $request){
        $orderId=$request->order_id;
		$message=$request->message;

		$order=Order::where('id',$orderId)->first();

		$order->status="CANCELLED";
		$order->status_updated_at=now();
		$order->message=$message;

		$order->save();

		$notificationMsg="";$title="";

		if($order->tag_type=="TRAIN-TICKET"){
			$notificationMsg="Train Ticket request ";
		}else if($order->tag_type=="BUS-TICKET"){
			$notificationMsg="Bus Ticket ";
		}else if($order->tag_type=="FLIGHT-TICKET"){
			$notificationMsg="Flight Ticket request ";
		}else if($order->tag_type=="ELECTRIC-BILL"){
			$notificationMsg="Electric Bill request ";
		}else if($order->tag_type=="MOBILE-RECHARGE"){
			$notificationMsg="Mobile Recharge request ";
		}else if($order->tag_type=="DTH-RECHARGE"){
			$notificationMsg="DTH Recharge request ";
		}

		$user=User::where('id',$order->user_id)->first();

		$title="Order cancelled";
		$notificationMsg=$notificationMsg."cancelled by ".$user->name;

        $admin=Admin::where('id',0)->first();

		$tokenList=[];
		array_push($tokenList,$admin->token);

		$this->notification($tokenList,$title,$notificationMsg);

		return response()->json(['status' => 'SUCCESS', 'code' => 'SC_01', 'data' => $order]);	
    }


     //20. Get Transactions
     public function get_my_transactions(Request $request){
         $fromId=$request->from_id;
         $userId=$request->user_id;

         if($fromId==0){
            $transactions=Transaction::where('user_id',$userId)
                                    ->orderBy('created_at','DESC')
                                    ->orderBy('id','DESC')
                                    ->limit(20)
                                    ->get();
         }else{
            $transactions=Transaction::where('user_id',$userId)
                                    ->where('id','<',$userId)
                                    ->orderBy('created_at','DESC')
                                    ->orderBy('id','DESC')
                                    ->limit(20)
                                    ->get();
         }

         return response()->json(['status' => 'SUCCESS', 'code' => 'SC_01', 'data' => $transactions]);	 
     }


    //21. Get my transaction total
    public function get_transaction_total(Request $request){
        $user=User::where('id',$request->user_id)->first();

        $transactionData=[];
        $transactionData['total_amount']=$user->due_balance;

        return response()->json(['status' => 'SUCCESS', 'code' => 'SC_01', 'data' => $transactionData]);	 
    }






    


    public function notification($tokenList, $title, $message)
	{

        $setting=Setting::where('id',1)->first();

        $auth=$setting->google_auth;

		$fcmUrl = 'https://fcm.googleapis.com/fcm/send';
		// $token=$token;

		$notification = [
			'title' => $title,
			'body' => $message,
			'sound' => true,
		];

		$extraNotificationData = ["message" => $notification];

		$fcmNotification = [
			'registration_ids' => $tokenList, //multple token array
			// 'to'        => $token, //single token
			'notification' => $notification,
			'data' => $extraNotificationData
		];

		$headers = [
			'Authorization: key=' . $auth,
			'Content-Type: application/json'
		];


		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $fcmUrl);
		curl_setopt($ch, CURLOPT_POST, true);
		curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fcmNotification));
		$result = curl_exec($ch);
		curl_close($ch);

		return true;
	}


}
