<?php

use App\Http\Controllers\AdminController;
use App\Http\Controllers\UserController;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});


//User Controller
Route::post('send_otp',[UserController::class,'send_otp']);
Route::post('verify_otp',[UserController::class,'verify_otp']);
Route::post('register_user',[UserController::class,'register_user']);
Route::post('update_profile',[UserController::class,'update_profile']);
Route::post('get_accounts',[UserController::class,'get_accounts']);
Route::post('get_my_chats',[UserController::class,'get_my_chats']);
Route::post('book_train_ticket',[UserController::class,'book_train_ticket']);
Route::post('book_bus_ticket',[UserController::class,'book_bus_ticket']);
Route::post('book_flight_ticket',[UserController::class,'book_flight_ticket']);
Route::post('electric_bill_payment',[UserController::class,'electric_bill_payment']);
Route::post('mobile_recharge_payment',[UserController::class,'mobile_recharge_payment']);
Route::post('dth_recharge',[UserController::class,'dth_recharge']);
Route::get('get_mobile_operators',[UserController::class,'get_mobile_operators']);
Route::get('get_dth_operators',[UserController::class,'get_dth_operators']);
Route::get('get_account_details/{orderId}',[UserController::class,'get_account_details']);
Route::get('get_my_profile/{userId}',[UserController::class,'get_my_profile']);
Route::post('send_enquiry_message',[UserController::class,'send_enquiry_message']);
Route::get('mark_message_read/{messageId}',[UserController::class,'mark_message_read']);
Route::post('cancel_request',[UserController::class,'cancel_request']);
Route::post('get_my_transactions',[UserController::class,'get_my_transactions']);
Route::post('get_transaction_total',[UserController::class,'get_transaction_total']);



//Admin Controller

Route::post('login_admin',[AdminController::class,'login_admin']);
Route::post('get_orders',[AdminController::class,'get_orders']);
Route::get('get_order_details/{orderId}',[AdminController::class,'get_order_details']);
Route::post('account_data_range',[AdminController::class,'account_data_range']);
Route::post('get_chat_users',[AdminController::class,'get_chat_users']);
Route::post('get_message_by_id',[AdminController::class,'get_message_by_id']);
Route::post('get_users_list',[AdminController::class,'get_users_list']);
Route::get('get_users_detail/{userId}',[AdminController::class,'get_users_detail']);
Route::get('block_unblock_user/{userId}',[AdminController::class,'block_unblock_user']);
Route::post('send_user_notification',[AdminController::class,'send_user_notification']);
Route::post('send_notificaiton_category',[AdminController::class,'send_notificaiton_category']);
Route::post('accept_reject_order',[AdminController::class,'accept_reject_order']);
Route::post('cancel_request_admin',[AdminController::class,'cancel_request_admin']);
Route::post('mark_order_complete',[AdminController::class,'mark_order_complete']);
Route::post('add_due_balance',[AdminController::class,'add_due_balance']);
Route::post('settle_transaction',[AdminController::class,'settle_transaction']);
Route::post('due_remainder_everyone',[AdminController::class,'due_remainder_everyone']);
Route::post('due_remainder_single_user',[AdminController::class,'due_remainder_single_user']);
Route::post('get_transaction_total_range',[AdminController::class,'get_transaction_total_range']);